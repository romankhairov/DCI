// Copyright 1998-2017 Epic Games, Inc. All Rights Reserved.

#include "PakExportRuntime.h"

DEFINE_LOG_CATEGORY(LogPakExportRuntime);

IMPLEMENT_MODULE(FPakExportRuntimeModule, PakExportRuntime)
